class RollsRoyce:

    def __init__(self):
        pass

    def start(self):
        print("Engine started")

    def stop(self):
        print("Engine stopped")